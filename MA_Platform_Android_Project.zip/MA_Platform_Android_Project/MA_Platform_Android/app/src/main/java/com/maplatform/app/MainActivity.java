package com.maplatform.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        // WebViewClient عادي يبقي التصفح داخل نفس الـ WebView (بدون فتح متصفح خارجي)
        webView.setWebViewClient(new WebViewClient());

        // جسر الطباعة: تستدعيه صفحات HTML عبر window.AndroidPrint.print()
        webView.addJavascriptInterface(new AndroidPrintBridge(), "AndroidPrint");

        // جسر القراءة الصوتية: تستدعيه صفحات HTML عبر window.AndroidTTS.speak(text)
        webView.addJavascriptInterface(new AndroidTTSBridge(), "AndroidTTS");

        // تهيئة محرك النطق الأصلي لأندرويد (WebView لا يدعم speechSynthesis إطلاقاً)
        tts = new TextToSpeech(this, this);

        // نقطة الدخول: الصفحة الرئيسية للمنصة داخل مجلد assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("ar", "SA"));
            // إذا لم تتوفر حزمة الصوت العربية بالضبط، نترك اللغة الافتراضية
            // للجهاز بدل رفض التشغيل بالكامل
            ttsReady = (result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED);
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /**
     * الجسر بين جافاسكريبت وأندرويد للطباعة.
     * عندما تستدعي صفحة HTML الدالة nativePrint()، فإنها تتحقق من وجود
     * window.AndroidPrint وتستدعي print() هنا، مما يفتح مربع حوار الطباعة
     * الأصلي في أندرويد (نفس الذي يظهر عند الطباعة من كروم أو أي تطبيق آخر).
     */
    private class AndroidPrintBridge {
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager printManager =
                        (PrintManager) getSystemService(PRINT_SERVICE);
                if (printManager == null) return;

                String jobName = getString(R.string.app_name) + " - مستند";
                PrintDocumentAdapter printAdapter =
                        webView.createPrintDocumentAdapter(jobName);

                printManager.print(
                        jobName,
                        printAdapter,
                        new PrintAttributes.Builder().build()
                );
            });
        }
    }

    /**
     * الجسر بين جافاسكريبت وأندرويد للقراءة الصوتية (نص إلى كلام).
     * WebView الأساسي في أندرويد لا يطبّق واجهة speechSynthesis إطلاقاً (خطأ
     * معروف وغير محلول في Chromium)، لذلك نستخدم محرك android.speech.tts
     * الأصلي بدلاً منه. تستدعي صفحات HTML هذا عبر nativeSpeak(text).
     */
    private class AndroidTTSBridge {
        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (tts == null || !ttsReady || text == null || text.isEmpty()) return;
                tts.stop();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ma_platform_tts");
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                if (tts != null) tts.stop();
            });
        }
    }
}

